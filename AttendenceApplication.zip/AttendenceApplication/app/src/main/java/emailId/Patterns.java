package emailId;

public class Patterns {
}
