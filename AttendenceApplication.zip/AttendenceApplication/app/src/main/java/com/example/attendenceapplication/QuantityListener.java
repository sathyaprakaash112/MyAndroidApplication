package com.example.attendenceapplication;

import java.util.ArrayList;

public interface QuantityListener {
    void onQuantityChange(ArrayList<Student> arrayList);
}
