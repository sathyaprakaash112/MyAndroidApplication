package com.example.attendenceapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Add_students_intro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_students_intro);
    }
}