package com.example.attendenceapplication;

import java.util.ArrayList;

public interface AbsenteesListener {
    void onQuantityChange(ArrayList<Student> arrayList);
}
