package com.example.attendenceapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class AddStudent extends AppCompatActivity {

    String mymessage;
    Button next,back,finish;
    FirebaseFirestore firestore;
    EditText studentName,regNo,phoneNo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String data = prefs.getString("message","no_id");

        Bundle bundle = getIntent().getExtras();
//        mymessage =bundle.getString("message");
        System.out.println(mymessage);

        back = findViewById(R.id.backbutton);
        finish = findViewById(R.id.finishbutton);
        next = findViewById(R.id.nextbutton);
        studentName = findViewById(R.id.Sname);
        regNo = findViewById(R.id.regno);
        phoneNo = findViewById(R.id.phonenumber);


        String name = studentName.getText().toString();
        String reg = regNo.getText().toString();
        String phone = phoneNo.getText().toString();


        firestore = FirebaseFirestore.getInstance();
        //studentName.setText(message);


        next.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                HashMap<String,String> hm = new HashMap<>();
                hm.put("studentName",studentName.getText().toString());
                hm.put("registernumber",regNo.getText().toString());
                hm.put("phoneNo",phoneNo.getText().toString());
                DocumentReference documentReference = firestore.collection("users").document(userid).collection("classes").document(data).collection("Students").document(regNo.getText().toString());
                documentReference.set(hm).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(AddStudent.this, "Student added successfully. Please add the next Student.", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), AddStudent.class);
                        intent.putExtra("mymessage", mymessage);
                        intent.putExtra("registernumber",reg);
                        startActivity(intent);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddStudent.this, "Database error occurred", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                HashMap<String,String> hm = new HashMap<>();
                hm.put("studentName",studentName.getText().toString());
                hm.put("registernumber",regNo.getText().toString());
                hm.put("phoneNo",phoneNo.getText().toString());
                DocumentReference documentReference = firestore.collection("users").document(userid).collection("classes").document(data).collection("Students").document(regNo.getText().toString());
                documentReference.set(hm).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(AddStudent.this, "Student added  successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), AttendancePage.class);
                        intent.putExtra("mymessage", mymessage);
                        intent.putExtra("registernumber",reg);
                        startActivity(intent);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddStudent.this, "Database error occurred", Toast.LENGTH_SHORT).show();
                    }
                });
            }

        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveTaskToBack(true);
            }
        });
    }
}